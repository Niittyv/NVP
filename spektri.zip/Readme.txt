Ohjelmoinnin alkeet syksy 2019 -lopputy�.
https://lovelace.oulu.fi/ohjelmoinnin-alkeet/ohjelmoinnin-alkeet/spektri�-pukkaa/

Sis�lt�� erillisen� muokattua testidataa, jossa measurement_0 -tiedostossa on
virheellist� dataa (tokan intensiteetin tilalla merkkijono). Lis�ksi
measurement_2 -tiedoston toista energia-arvoa on muutettu, joten tiedostojen
energia-arvot eiv�t ole yhtenevi�.

-Ohjelman suorittamista varten vaadittava ikkunasto-kirjasto sis�ltyy zip-kansioon.
-K�ytt�j�ll� tulee olla asennettuna Python 3.7 ja sen lis�ksi Matplotlib-ja 
Numpy -kirjastot.

