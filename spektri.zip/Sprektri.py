import matplotlib
import matplotlib.pyplot as plt
import numpy
import os
import ikkunasto as ik

sanakirja = {
    "tiedostojen_lkm": None,
    "VIRHETIEDOSTOT": [],
    "energia-akselit_yhtenevyys": True,
    "tekstilaatikko": None,
    "x_data": None, # Energia-akselin arvot
    "y_data": None, # Intensiteettisummat
    "y_data2": None, # Intensiteettisummat joista lineaarinen tausta poistettu
    "integraali1": None, # Ensimmäisen energiavälin pinta-ala
    "integraali2": None # Toisen energiavälin pinta-ala
}

KOORDINAATIT = [] # Hiiren klikkauksesta saatavat alkiot monikkoina

def lataa_data(kansio):
    """
    Tarkistaa parametrinä annetusta hakemistosta 'measurement'-alkuiset ja '.txt'-loppuiset tiedostot ja lukee niiden riveistä kineettiset energiat ja 
    summatut intensiteettispektrit omiin listoihinsa. Tallentaa sanakirjaan ladattujen tiedostojen lukumäärän ja virheellistä dataa sisältävät tiedostot.
    
    :param str kansio: Hakemiston väylä
    :return: kineettiset energiat lista ja summatut intensiteettispektrit lista
    """
    ENERGIAT = [] # Sisältää jokaisen tiedoston energiat listoina. 2-ulotteinen lista
    INTENSITEETIT = [] # Sisältää jokaisen tiedoston intensiteetit listoina. 2-ulotteinen lista
    SISALTO = os.listdir(kansio)
    for tiedosto in SISALTO:
        if tiedosto.startswith("measurement") and tiedosto.endswith(".txt"):
            with open(os.path.join(kansio, tiedosto)) as f:
                RIVIT = f.readlines()
                filter(None, RIVIT)
                tiedoston_luettavuus = True
                TIEDOSTO_ENERGIAT = []
                TIEDOSTO_INTENSITEETIT = []
                for rivi in RIVIT:
                    rivi.strip()
                    try:
                        energia, intensiteetti = rivi.split(" ")
                        TIEDOSTO_ENERGIAT.append(float(energia))
                        TIEDOSTO_INTENSITEETIT.append(float(intensiteetti))
                    except ValueError:
                        tiedoston_luettavuus = False
                        sanakirja["VIRHETIEDOSTOT"].append(tiedosto)
                if tiedoston_luettavuus:
                    ENERGIAT.append(TIEDOSTO_ENERGIAT)
                    INTENSITEETIT.append(TIEDOSTO_INTENSITEETIT)
    ENERGIA_AKSELI = ENERGIAT[0] # Valitsee ensimmäisen tiedoston energia-listan arvot vaaka-akseliksi
    # Tarkastaa, ovatko kaikki energia-listat samanlaisia. Myöhemmin kertoo myös, mikä lista poikkeaa energia-akselista
    for akseli in ENERGIAT:
        if akseli != ENERGIA_AKSELI:
            sanakirja["energia-akselit_yhtenevyys"] = False
    INTENSITEETTI_SUMMA = [sum(i) for i in zip(*INTENSITEETIT)] # Summaa jokaisen INTENSITEETIT-listan sisältämien listojen alkiot yhteen ja luo niistä pystyakselin
    sanakirja["tiedostojen_lkm"] = len(ENERGIAT)
    return ENERGIA_AKSELI, INTENSITEETTI_SUMMA


def valitse_kansio():
    """
    Antaa käyttäjälle mahdollisuuden valita hakemiston jonka funktio palauttaa merkkijonona
    :return: hakemiston polku merkkijonona
    """
    polku = ik.avaa_hakemistoikkuna("Valitse datakansio")
    return polku

def main():
    ikkuna1 = ik.luo_ikkuna("TEKSTIKENTTÄ")
    ylakehys1 = ik.luo_kehys(ikkuna1, ik.YLA)
    alakehys1 = ik.luo_kehys(ikkuna1, ik.YLA)
    sanakirja["tekstilaatikko"] = ik.luo_tekstilaatikko(ylakehys1)
    tekstilaatikko_nappi1 = ik.luo_nappi(alakehys1, "Valitse uudet pisteet", resetoi_pisteet)
    tekstilaatikko_nappi2 = ik.luo_nappi(alakehys1, "Poista lineaarinen tausta", poista_tausta)
    tekstilaatikko_nappi3 = ik.luo_nappi(alakehys1, "Integroi ensimmäinen väli", intensiteetti1_kasittelija)
    tekstilaatikko_nappi4 = ik.luo_nappi(alakehys1, "Integroi toinen väli", intensiteetti2_kasittelija)
    tekstilaatikko_nappi5 = ik.luo_nappi(alakehys1, "Suhteuta integraalit", suhteuta_pinta_alat)
    tekstilaatikko_nappi6 = ik.luo_nappi(alakehys1, "Hae data", kuvaaja_kasittelija)
    tekstilaatikko_nappi7 = ik.luo_nappi(alakehys1, "Lopeta", ik.lopeta)
    ik.kirjoita_tekstilaatikkoon(sanakirja["tekstilaatikko"], "Valitse hakemisto josta mittausdata ladataan painamalla 'Hae data'")
    ik.kaynnista()


def valitse_piste(event):
    """Ottaa käyttäjän klikkaustapahtuman ohjelman listaan"""
    ix, iy = event.xdata, event.ydata
    KOORDINAATIT.append((ix, iy))
    print(KOORDINAATIT)
    if len(KOORDINAATIT) <= 2:
        ik.kirjoita_tekstilaatikkoon(sanakirja["tekstilaatikko"], "Valitsit pisteen x = {:.2f}, y = {:.2f}".format(ix, iy))


def resetoi_pisteet():
    KOORDINAATIT[:] = [] # Tyhjentää klikkaustapahtumat
    ilmoita_kayttajalle()


def jarjestele_koordinaatit():
    """Palauttaa ensimmäisen ja toisen klikkaustapahtuman alkiot"""
    try:
        # Neljä ensimmäistä KOORDINAATIT-listan alkiota
        x1 = KOORDINAATIT[0][0]
        y1 = KOORDINAATIT[0][1]
        x2 = KOORDINAATIT[1][0]
        y2 = KOORDINAATIT[1][1]
        if not x1 or not y1 or not x2 or not y2:
            resetoi_pisteet()
            ik.kirjoita_tekstilaatikkoon(sanakirja["tekstilaatikko"], "VALITSE UUDET PISTEET")
    except IndexError:
        ik.kirjoita_tekstilaatikkoon(sanakirja["tekstilaatikko"], "Pisteitä ei ole valittu")
    else:
        return x1, y1, x2, y2


def muodosta_suoran_yhtalo():
    """Palauttaa kulmakertoimen ja vakiotermin annettujen koordinaattien välisestä suorasta"""
    try:
        x1, y1, x2, y2 = jarjestele_koordinaatit()
    except ValueError:
        pass
    else:
        try:
            kulmakerroin = (y2 - y1) / (x2 - x1)
            vakiotermi = (x2 * y1 - x1 * y2) / (x2 - x1)
        except ZeroDivisionError:
            ik.kirjoita_tekstilaatikkoon(sanakirja["tekstilaatikko"], "Yhtälöä ei voida muodostaa, sillä suora on pystysuora")
        else:
            return kulmakerroin, vakiotermi


def laske_suoran_arvot():
    """Muodostaa suoran arvoista listan sijoittamalla x-listan alkioita suoran yhtälöön
    :return: Lista suoran arvoista
    """
    x_arvot = sanakirja["x_data"]
    y_arvot = [] # Suoran arvot
    try:
        k, b = muodosta_suoran_yhtalo()
        for x in x_arvot:
            y_arvo = k * x + b
            y_arvot.append(y_arvo)
    except ValueError:
        pass
    else:
        return y_arvot


def poista_tausta():
    """Vähentää kustakin intensiteettilistan alkiosta vastaavan suoran arvon ja luo uuden kuvaajan ilman lineaarista taustaa"""
    suoran_arvot = laske_suoran_arvot()
    intensiteetit = sanakirja["y_data"]
    uudet_intensiteetit = [y1 - y2 for (y1, y2) in zip(intensiteetit, suoran_arvot)]
    x_data = sanakirja["x_data"] #Tarvitaan kuvaajan luomista varten
    sanakirja["y_data2"] = uudet_intensiteetit
    resetoi_pisteet() #Tyhjentää KOORDINATIIT-listan, jotta käyttäjä voi valita uudet pisteet
    ik.kirjoita_tekstilaatikkoon(sanakirja["tekstilaatikko"], "\nValitse ensimmäinen integroimisväli klikkaamalla kahta pistettä jonka jälkeen paina 'Integroi ensimmäinen väli'")
    luo_kuvaaja(x_data, uudet_intensiteetit, "Without linear background")


def laske_intensiteetti(x_data, y_data):
    """Ottaa jokaisen x1 ja x2 välillä olevan y:n arvon ja integroi kyseiset arvot käyttämällä puolisuunnikassääntöä
    :return: kuvaajan pinta-alan liukulukuna annetulla välillä
    """
    x1, y1, x2, y2 = jarjestele_koordinaatit() # Klikkaustapahtumasta saadut arvot
    y_arvot = [] # x1 ja x2 välillä olevat kuvaajan arvot
    for x_arvo in x_data:
        if x_arvo >= x1 and x_arvo <= x2:
            y_arvot.append(y_data[x_data.index(x_arvo)]) # Lisää kuvaajan arvoja sisältävään listaan jokaisen x1 ja x2 välillä olevaa x-arvoa vastaavan y-arvon
    pinta_ala = numpy.trapz(y_arvot, dx=0.01) # Integroi annetut y:n arvot
    if pinta_ala == 0:
        ik.kirjoita_tekstilaatikkoon(sanakirja["tekstilaatikko"], "Pinta-ala on 0")
    else:
        return pinta_ala
        

def suhteuta_pinta_alat():
    pinta_ala1 = sanakirja["integraali1"]
    pinta_ala2 = sanakirja["integraali2"]
    if pinta_ala2 == 0:
        ik.kirjoita_tekstilaatikkoon(sanakirja["tekstilaatikko"], "Suhdetta ei voida muodostaa")
    else:
        suhde = pinta_ala1 / pinta_ala2
        ik.kirjoita_tekstilaatikkoon(sanakirja["tekstilaatikko"], "Ensimmäisen energiavälin intensiteetin suhde toisen energiavälin intensiteettiin on {:.2f}".format(abs(suhde)))
    

def intensiteetti1_kasittelija():
    """Toimii napin käsittelijänä ensimmäiselle integrointivälille"""
    x_data = sanakirja["x_data"]
    # Mahdollisuus integroida kuvaaja lineaarisella taustalla tai ilman lineaarista taustaa
    if sanakirja["y_data2"]:
        y_data = sanakirja["y_data2"]
    else:
        y_data = sanakirja["y_data"]
    pinta_ala1 = laske_intensiteetti(x_data, y_data)
    sanakirja["integraali1"] = pinta_ala1
    resetoi_pisteet() #Tyhjentää KOORDINATIIT-listan, jotta käyttäjä voi valita uudet pisteet toiselle integroimiselle
    ik.kirjoita_tekstilaatikkoon(sanakirja["tekstilaatikko"], "Ensimmäisen piikin pinta-ala: {:.2f}\nValitse toinen integroimisväli klikkaamalla kahta pistettä jonka jälkeen paina 'Integroi toinen väli' ".format(abs(pinta_ala1)))


def intensiteetti2_kasittelija():
    """Toimii napin käsittelijänä toiselle integrointivälille"""
    x_data = sanakirja["x_data"]
    # Mahdollisuus integroida kuvaaja lineaarisella taustalla tai ilman lineaarista taustaa
    if sanakirja["y_data2"]:
        y_data = sanakirja["y_data2"]
    else:
        y_data = sanakirja["y_data"]
    pinta_ala2 = laske_intensiteetti(x_data, y_data)
    sanakirja["integraali2"] = pinta_ala2
    ik.kirjoita_tekstilaatikkoon(sanakirja["tekstilaatikko"], "Toisen piikin pinta-ala: {:.2f}\nSuhteuta ensimmäisen piikin pinta-ala toisen piikin pinta-alaan painamalla 'Suhteuta integraalit'".format(abs(pinta_ala2)))


def kuvaaja_kasittelija():
    """Toimii napinkäsittelijänä kuvaajan luontia varten käyttäjän valitsemasta hakemistosta saadusta datasta"""
    try:
        polku = valitse_kansio() # Käyttäjän valitsema hakemisto
        x_data, y_data = lataa_data(polku) 
        sanakirja["x_data"] = x_data
        sanakirja["y_data"] = y_data
    except IndexError:
        ik.kirjoita_tekstilaatikkoon(sanakirja["tekstilaatikko"], "Dataa  ei ladattu")
    else:
        ilmoita_kayttajalle() # Ilmoittaa käyttäjälle datan latauksessa syntyneet tapahtumat
        ik.kirjoita_tekstilaatikkoon(sanakirja["tekstilaatikko"], "\nPoista lineaarinen tausta valitsemalla pisteet kuvaajan molemmista päistä klikkaamalla sitä kaksi kertaa. Tämän jälkeen paina 'Poista lineaarinen tausta'. Tämä toiminto luo uuden ikkunan")
        luo_kuvaaja(x_data, y_data)


def luo_kuvaaja(x_data, y_data, otsikko=None):
    """Luo kuvaajan subplotilla ja yhdistää siihen klikkaustapahtuman"""
    fig = plt.figure(figsize=(8,8))
    ax1 = fig.add_subplot(111)
    ax1.plot(x_data, y_data)
    plt.xlabel("Binding energy (eV)")
    plt.ylabel("Intensity (arbitary units)")
    plt.title(otsikko)
    plt.connect('button_press_event', valitse_piste) # Yhdistää hiiritapahtuman käyttämällä käsittelijäfunktiota
    plt.show()


def ilmoita_kayttajalle():
    """Ilmoittaa käyttäjälle dataa ladattaessa virheellisestä datasta ja kuinka monta tiedostoa ladattiin. Kertoo myös mikäli energia-akselit eivät ole yhteneviä"""
    ik.kirjoita_tekstilaatikkoon(sanakirja["tekstilaatikko"], "Tiedostoja tallennettu: {tiedostojen_lkm}\nVirheellisiä tiedostoja: {VIRHETIEDOSTOT}".format(**sanakirja), tyhjaa=True)
    if not sanakirja["energia-akselit_yhtenevyys"]:
        ik.kirjoita_tekstilaatikkoon(sanakirja["tekstilaatikko"], "Luettujen tiedostojen energia-akselit eivät ole yhteneviä, energia-akseli piirretään ensimmäisestä luetusta tiedostosta")


if __name__ == "__main__":
    main()

                    

                
                
                    
    